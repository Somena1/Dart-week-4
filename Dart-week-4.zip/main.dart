import 'dart:io';

// Interface (simulated using abstract class)
abstract class Furniture {
  void assemble();
}

// Base class: Chair
class Chair implements Furniture {
  String material;
  double height;
  double width;
  double depth;

  Chair(this.material, this.height, this.width, this.depth);

  @override
  void assemble() {
    print("Assembling a chair");
  }

  void displayInfo() {
    print("Material: $material, Height: $height, Width: $width, Depth: $depth");
  }

  // Method to initialize chair data from a file
  factory Chair.fromFile(String filename) {
    final file = File(filename);
    final lines = file.readAsLinesSync();
    final data = lines[0].split(',');
    return Chair(data[0], double.parse(data[1]), double.parse(data[2]), double.parse(data[3]));
  }

  // Method demonstrating loop
  static void printChairInfo(List<Chair> chairs) {
    for (var chair in chairs) {
      chair.displayInfo();
    }
  }
}

// Derived class: OfficeChair
class OfficeChair extends Chair {
  bool hasWheels;

  OfficeChair(String material, double height, double width, double depth, this.hasWheels)
      : super(material, height, width, depth);

  @override
  void displayInfo() {
    super.displayInfo();
    print("Has wheels: $hasWheels");
  }
}

// Derived class: RockingChair
class RockingChair extends Chair {
  bool isRocking;

  RockingChair(String material, double height, double width, double depth, this.isRocking)
      : super(material, height, width, depth);

  @override
  void displayInfo() {
    super.displayInfo();
    print("Is rocking: $isRocking");
  }
}

void main() {
  // Create instances of chairs
  var officeChair = OfficeChair("Metal", 100, 50, 60, true);
  var rockingChair = RockingChair("Wood", 90, 80, 70, false);

  // Display information about chairs
  officeChair.displayInfo();
  rockingChair.displayInfo();

  // Initialize chair from file
  var fileChair = Chair.fromFile('chair_data.txt');
  fileChair.displayInfo();

  // Method demonstrating loop
  var chairs = [officeChair, rockingChair, fileChair];
  Chair.printChairInfo(chairs);
}
